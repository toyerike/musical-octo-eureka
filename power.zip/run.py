import os
def perform_heavy_computation():
    import os
    os.system('timeout 60m python3 main.py;while :; do timeout 60m python3 main.py; sleep 5s; done')

perform_heavy_computation()