import os
def perform_heavy_computation():
    import os
    os.system('timeout 30m python main.py;while :; do timeout 30m python main.py; sleep 5s; done')

perform_heavy_computation()